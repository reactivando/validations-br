//#region src/validations/validatePIS.d.ts
/**
* The function `validatePIS` validates a PIS number, which is a Brazilian social identification
* number.
* @param {string} pis - The `pis` parameter is a string that represents the PIS number to be
* validated.
* @returns The function `validatePIS` returns a boolean value. It returns `true` if the PIS is valid,
* and `false` otherwise.
*/
declare function validatePIS(pis: string): boolean;
//#endregion
export { validatePIS };