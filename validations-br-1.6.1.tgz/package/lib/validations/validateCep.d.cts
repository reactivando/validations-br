//#region src/validations/validateCep.d.ts
declare function validateCep(cep: string): boolean;
//#endregion
export { validateCep };