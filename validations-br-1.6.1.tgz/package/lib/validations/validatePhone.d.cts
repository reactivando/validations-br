//#region src/validations/validatePhone.d.ts
/**
* The function `validatePhone` validates a Brazilian phone number.
* @param {string} phone - The `phone` parameter is a string that represents the phone number to be
* validated.
* @returns The function `validatePhone` returns a boolean value. It returns `true` if the phone number
* is valid, and `false` otherwise.
*/
declare function validatePhone(phone: string): boolean;
//#endregion
export { validatePhone };