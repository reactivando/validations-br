//#region src/validations/validateEmail.d.ts
declare function validateEmail(value: string): boolean;
//#endregion
export { validateEmail };