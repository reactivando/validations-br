//#region src/validations/validateCNH.d.ts
/**
* The function `validateCNH` validates a Brazilian driver's license number (CNH).
* @param {string} value - The `value` parameter is a string that represents the CNH (Carteira Nacional
* de Habilitação) number to be validated. It can be formatted with or without punctuation.
* @returns The function `validateCNH` returns a boolean value, indicating whether the provided CNH is
* valid or not.
*/
declare function validateCNH(value: string): boolean;
//#endregion
export { validateCNH };