//#region src/validations/ie/index.d.ts
/**
* The function `validateIE` validates a Brazilian state registration number (IE) for a given state
* (UF).
* @param {string} ie - The `ie` parameter is a string that represents the "Inscrição Estadual" (State
* Registration) number of a company in Brazil.
* @param {string} uf - The `uf` parameter is the state (UF) for which the IE is being validated. It
* can be in uppercase or lowercase.
* @returns The `validateIE` function returns a boolean value. It returns `true` if the provided `ie`
* is a valid state registration number for the given state `uf`, and `false` otherwise.
*/
declare function validateIE(ie: string, uf: string): boolean;
//#endregion
export { validateIE };