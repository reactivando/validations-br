//#region src/validations/ie/states/mg.d.ts
/**
* The function `validateMG` validates the state registration number (IE) for the state of Minas Gerais
* (MG) in Brazil.
* @param {string} ie - The `ie` parameter is a string that represents the state registration number of
* a company in the state of Minas Gerais (MG).
* @returns The function `validateMG` returns a boolean value. It returns `true` if the IE is valid,
* and `false` otherwise.
*/
declare function validateMG(ie: string): boolean;
//#endregion
export { validateMG };