import { validateCE } from "./ce.mjs";
export { validateCE as validateSC };