//#region src/validations/ie/states/df.d.ts
/**
* The function `validateDF` validates the state registration number (IE) for the Federal District (DF)
* in Brazil.
* @param {string} ie - The `ie` parameter is a string that represents the state registration number of
* a company in the Federal District (DF).
* @returns The function `validateDF` returns a boolean value. It returns `true` if the IE is valid,
* and `false` otherwise.
*/
declare function validateDF(ie: string): boolean;
//#endregion
export { validateDF };