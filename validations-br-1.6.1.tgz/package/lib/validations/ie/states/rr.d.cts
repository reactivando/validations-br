//#region src/validations/ie/states/rr.d.ts
/**
* The function `validateRR` validates the state registration number (IE) for the state of Roraima (RR)
* in Brazil.
* @param {string} ie - The `ie` parameter is a string that represents the state registration number of
* a company in the state of Roraima (RR).
* @returns The function `validateRR` returns a boolean value. It returns `true` if the IE is valid,
* and `false` otherwise.
*/
declare function validateRR(ie: string): boolean;
//#endregion
export { validateRR };