//#region src/validations/ie/states/sp.d.ts
/**
* The function `validateSP` validates the state registration number (IE) for the state of São Paulo
* (SP) in Brazil.
* @param {string} ie - The `ie` parameter is a string that represents the state registration number of
* a company in the state of São Paulo (SP).
* @returns The function `validateSP` returns a boolean value. It returns `true` if the IE is valid,
* and `false` otherwise.
*/
declare function validateSP(ie: string): boolean;
//#endregion
export { validateSP };