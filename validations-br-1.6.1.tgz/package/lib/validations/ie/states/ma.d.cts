//#region src/validations/ie/states/ma.d.ts
/**
* The function `validateMA` validates the state registration number (IE) for the state of Maranhão
* (MA) in Brazil.
* @param {string} ie - The `ie` parameter is a string that represents the state registration number of
* a company in the state of Maranhão (MA).
* @returns The function `validateMA` returns a boolean value. It returns `true` if the IE is valid,
* and `false` otherwise.
*/
declare function validateMA(ie: string): boolean;
//#endregion
export { validateMA };