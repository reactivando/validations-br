//#region src/validations/ie/states/ap.d.ts
/**
* The function `validateAP` validates the state registration number (IE) for the state of Amapá (AP)
* in Brazil.
* @param {string} ie - The `ie` parameter is a string that represents the state registration number of
* a company in the state of Amapá (AP).
* @returns The function `validateAP` returns a boolean value. It returns `true` if the IE is valid,
* and `false` otherwise.
*/
declare function validateAP(ie: string): boolean;
//#endregion
export { validateAP };