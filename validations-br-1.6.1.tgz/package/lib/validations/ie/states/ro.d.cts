//#region src/validations/ie/states/ro.d.ts
/**
* The function `validateRO` validates the state registration number (IE) for the state of Rondônia
* (RO) in Brazil.
* @param {string} ie - The `ie` parameter is a string that represents the state registration number of
* a company in the state of Rondônia (RO).
* @returns The function `validateRO` returns a boolean value. It returns `true` if the IE is valid,
* and `false` otherwise.
*/
declare function validateRO(ie: string): boolean;
//#endregion
export { validateRO };