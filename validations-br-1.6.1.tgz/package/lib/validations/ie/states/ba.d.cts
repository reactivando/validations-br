//#region src/validations/ie/states/ba.d.ts
/**
* The function `validateBA` validates the state registration number (IE) for the state of Bahia (BA)
* in Brazil.
* @param {string} ie - The `ie` parameter is a string that represents the state registration number of
* a company in the state of Bahia (BA).
* @returns The function `validateBA` returns a boolean value. It returns `true` if the IE is valid,
* and `false` otherwise.
*/
declare function validateBA(ie: string): boolean;
//#endregion
export { validateBA };