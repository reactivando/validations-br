//#region src/validations/ie/states/rs.d.ts
/**
* The function `validateRS` validates the state registration number (IE) for the state of Rio Grande
* do Sul (RS) in Brazil.
* @param {string} ie - The `ie` parameter is a string that represents the state registration number of
* a company in the state of Rio Grande do Sul (RS).
* @returns The function `validateRS` returns a boolean value. It returns `true` if the IE is valid,
* and `false` otherwise.
*/
declare function validateRS(ie: string): boolean;
//#endregion
export { validateRS };