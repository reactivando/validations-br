//#region src/validations/ie/states/mt.d.ts
/**
* The function `validateMT` validates the state registration number (IE) for the state of Mato Grosso
* (MT) in Brazil.
* @param {string} ie - The `ie` parameter is a string that represents the state registration number of
* a company in the state of Mato Grosso (MT).
* @returns The function `validateMT` returns a boolean value. It returns `true` if the IE is valid,
* and `false` otherwise.
*/
declare function validateMT(ie: string): boolean;
//#endregion
export { validateMT };