//#region src/validations/ie/states/al.d.ts
/**
* The function `validateAL` validates the state registration number (IE) for the state of Alagoas (AL)
* in Brazil.
* @param {string} ie - The `ie` parameter is a string that represents the state registration number of
* a company in the state of Alagoas (AL).
* @returns The function `validateAL` returns a boolean value. It returns `true` if the IE is valid,
* and `false` otherwise.
*/
declare function validateAL(ie: string): boolean;
//#endregion
export { validateAL };