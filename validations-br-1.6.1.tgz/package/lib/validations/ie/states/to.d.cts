//#region src/validations/ie/states/to.d.ts
/**
* The function `validateTO` validates the state registration number (IE) for the state of Tocantins
* (TO) in Brazil.
* @param {string} ie - The `ie` parameter is a string that represents the state registration number of
* a company in the state of Tocantins (TO).
* @returns The function `validateTO` returns a boolean value. It returns `true` if the IE is valid,
* and `false` otherwise.
*/
declare function validateTO(ie: string): boolean;
//#endregion
export { validateTO };