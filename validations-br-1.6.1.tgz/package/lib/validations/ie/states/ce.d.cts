//#region src/validations/ie/states/ce.d.ts
/**
* The function `validateCE` validates the state registration number (IE) for the state of Ceará (CE)
* in Brazil.
* @param {string} ie - The `ie` parameter is a string that represents the state registration number of
* a company in the state of Ceará (CE).
* @returns The function `validateCE` returns a boolean value. It returns `true` if the IE is valid,
* and `false` otherwise.
*/
declare function validateCE(ie: string): boolean;
//#endregion
export { validateCE };