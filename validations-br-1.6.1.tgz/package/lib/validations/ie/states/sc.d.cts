import { validateCE } from "./ce.cjs";
export { validateCE as validateSC };