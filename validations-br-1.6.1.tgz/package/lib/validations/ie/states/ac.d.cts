//#region src/validations/ie/states/ac.d.ts
/**
* The function `validateAC` validates the state registration number (IE) for the state of Acre (AC) in
* Brazil.
* @param {string} ie - The `ie` parameter is a string that represents the state registration number of
* a company in the state of Acre (AC).
* @returns The function `validateAC` returns a boolean value. It returns `true` if the IE is valid,
* and `false` otherwise.
*/
declare function validateAC(ie: string): boolean;
//#endregion
export { validateAC };