//#region src/validations/ie/states/rn.d.ts
/**
* The function `validateRN` validates the state registration number (IE) for the state of Rio Grande
* do Norte (RN) in Brazil.
* @param {string} ie - The `ie` parameter is a string that represents the state registration number of
* a company in the state of Rio Grande do Norte (RN).
* @returns The function `validateRN` returns a boolean value. It returns `true` if the IE is valid,
* and `false` otherwise.
*/
declare function validateRN(ie: string): boolean;
//#endregion
export { validateRN };