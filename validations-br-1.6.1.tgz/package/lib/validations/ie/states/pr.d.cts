//#region src/validations/ie/states/pr.d.ts
/**
* The function `validatePR` validates the state registration number (IE) for the state of Paraná (PR)
* in Brazil.
* @param {string} ie - The `ie` parameter is a string that represents the state registration number of
* a company in the state of Paraná (PR).
* @returns The function `validatePR` returns a boolean value. It returns `true` if the IE is valid,
* and `false` otherwise.
*/
declare function validatePR(ie: string): boolean;
//#endregion
export { validatePR };