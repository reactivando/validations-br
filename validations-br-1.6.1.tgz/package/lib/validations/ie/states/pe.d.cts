//#region src/validations/ie/states/pe.d.ts
/**
* The function `validatePE` validates the state registration number (IE) for the state of Pernambuco
* (PE) in Brazil.
* @param {string} ie - The `ie` parameter is a string that represents the state registration number of
* a company in the state of Pernambuco (PE).
* @returns The function `validatePE` returns a boolean value. It returns `true` if the IE is valid,
* and `false` otherwise.
*/
declare function validatePE(ie: string): boolean;
//#endregion
export { validatePE };