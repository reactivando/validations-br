//#region src/validations/ie/states/rj.d.ts
/**
* The function `validateRJ` validates the state registration number (IE) for the state of Rio de
* Janeiro (RJ) in Brazil.
* @param {string} ie - The `ie` parameter is a string that represents the state registration number of
* a company in the state of Rio de Janeiro (RJ).
* @returns The function `validateRJ` returns a boolean value. It returns `true` if the IE is valid,
* and `false` otherwise.
*/
declare function validateRJ(ie: string): boolean;
//#endregion
export { validateRJ };