//#region src/validations/ie/states/am.d.ts
/**
* The function `validateAM` validates the state registration number (IE) for the state of Amazonas (AM)
* in Brazil.
* @param {string} ie - The `ie` parameter is a string that represents the state registration number of
* a company in the state of Amazonas (AM).
* @returns The function `validateAM` returns a boolean value. It returns `true` if the IE is valid,
* and `false` otherwise.
*/
declare function validateAM(ie: string): boolean;
//#endregion
export { validateAM };