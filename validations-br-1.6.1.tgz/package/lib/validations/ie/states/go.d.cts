//#region src/validations/ie/states/go.d.ts
/**
* The function `validateGO` validates the state registration number (IE) for the state of Goiás (GO)
* in Brazil.
* @param {string} ie - The `ie` parameter is a string that represents the state registration number of
* a company in the state of Goiás (GO).
* @returns The function `validateGO` returns a boolean value. It returns `true` if the IE is valid,
* and `false` otherwise.
*/
declare function validateGO(ie: string): boolean;
//#endregion
export { validateGO };