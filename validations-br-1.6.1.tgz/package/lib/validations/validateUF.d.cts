//#region src/validations/validateUF.d.ts
declare function validateUF(uf: string): boolean;
//#endregion
export { validateUF };