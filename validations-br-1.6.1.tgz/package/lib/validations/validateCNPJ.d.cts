//#region src/validations/validateCNPJ.d.ts
/**
* The function `validateCNPJ` validates a Brazilian CNPJ number, supporting both the
* traditional numeric format and the alphanumeric format (12 uppercase alphanumeric
* positions followed by 2 numeric check digits) introduced by Receita Federal.
* @param {string} value - The `value` parameter is a string that represents the CNPJ
* (Cadastro Nacional da Pessoa Jurídica) to be validated. It can be formatted with or without
* punctuation, like '00.000.000/0000-00', '00000000000000' or '12.ABC.345/01DE-35'.
* @returns The function `validateCNPJ` returns a boolean value. It returns `true` if the CNPJ
* is valid, and `false` otherwise.
*/
declare function validateCNPJ(value: string): boolean;
//#endregion
export { validateCNPJ };