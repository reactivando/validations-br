//#region src/validations/validateCPF.d.ts
/**
* The function `validateCPF` validates a Brazilian CPF number, checking its length, format, and check
* digits.
* @param {string} value - The `value` parameter is a string that represents the CPF (Cadastro de
* Pessoas Físicas) number to be validated. It can be in the format '000.000.000-00' or
* '00000000000'.
* @returns The function `validateCPF` returns a boolean value. It returns `true` if the CPF is valid,
* and `false` otherwise.
*/
declare function validateCPF(value: string): boolean;
//#endregion
export { validateCPF };