//#region src/validations/usevalidationsbr.d.ts
declare const useValidationsBR: (type: "cnpj" | "cpf" | "cep" | "email" | "pis" | "phone" | "uf" | "cnh", value: string) => boolean;
//#endregion
export { useValidationsBR };